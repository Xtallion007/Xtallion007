'use client';

import SaveNairaApp from "@/components/SaveNairaApp";

export default function Home() {
  return <SaveNairaApp />;
}
