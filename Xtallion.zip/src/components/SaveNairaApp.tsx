'use client';

import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function SaveNairaApp() {
  const [amount, setAmount] = useState("");
  const [goal, setGoal] = useState(100000);
  const [customGoal, setCustomGoal] = useState(goal.toString());
  const [savings, setSavings] = useState<
    { id: number; amount: number; date: string }[]
  >([]);

  const totalSaved = savings.reduce((sum, s) => sum + s.amount, 0);
  const average = savings.length > 0 ? totalSaved / savings.length : 0;

  useEffect(() => {
    const storedSavings = localStorage.getItem("savings");
    const storedGoal = localStorage.getItem("goal");
    if (storedSavings) setSavings(JSON.parse(storedSavings));
    if (storedGoal) {
      setGoal(parseFloat(storedGoal));
      setCustomGoal(storedGoal);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("savings", JSON.stringify(savings));
    localStorage.setItem("goal", goal.toString());
  }, [savings, goal]);

  const handleSave = () => {
    const amt = parseFloat(amount);
    if (!amount || isNaN(amt) || amt <= 0) {
      alert("Please enter a valid amount greater than ₦0");
      return;
    }

    setSavings([
      ...savings,
      {
        id: Date.now(),
        amount: amt,
        date: new Date().toLocaleDateString(),
      },
    ]);
    setAmount("");
  };

  const handleGoalUpdate = () => {
    const newGoal = parseFloat(customGoal);
    if (!isNaN(newGoal) && newGoal > 0) {
      setGoal(newGoal);
    } else {
      alert("Enter a valid goal amount.");
    }
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear all savings?")) {
      setSavings([]);
      setGoal(100000);
      setCustomGoal("100000");
      localStorage.removeItem("savings");
      localStorage.removeItem("goal");
    }
  };

  const handleExportCSV = () => {
    if (savings.length === 0) {
      alert("No data to export.");
      return;
    }

    const header = "Date,Amount\n";
    const rows = savings.map((entry) => `${entry.date},${entry.amount}`).join("\n");
    const csv = header + rows;

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = "savings.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-md mx-auto p-4 space-y-4">
      <h1 className="text-2xl font-bold text-center">💰 SaveNaira</h1>

      <Card>
        <CardContent className="space-y-4 pt-4">
          <div className="flex gap-2 items-center">
            <Input
              type="number"
              placeholder="Set goal (₦)"
              value={customGoal}
              onChange={(e) => setCustomGoal(e.target.value)}
            />
            <Button onClick={handleGoalUpdate} variant="outline">
              Update Goal
            </Button>
          </div>

          <div className="flex gap-2">
            <Input
              type="number"
              placeholder="Enter amount (₦)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Button onClick={handleSave}>Save</Button>
          </div>

          <Progress value={(totalSaved / goal) * 100} />
          <p className="text-center text-sm">
            You’ve saved ₦{totalSaved.toLocaleString()} of ₦{goal.toLocaleString()}
          </p>

          <div className="flex justify-between pt-2">
            <Button onClick={handleExportCSV} variant="outline" size="sm">
              Export CSV
            </Button>
            <Button onClick={handleClearAll} variant="destructive" size="sm">
              Clear All
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="summary">
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="log">Savings Log</TabsTrigger>
        </TabsList>

        <TabsContent value="summary">
          <Card>
            <CardContent className="pt-4 space-y-4">
              <div className="text-sm text-center space-y-1">
                <p>📆 Total Entries: {savings.length}</p>
                <p>📊 Average Per Entry: ₦{average.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={savings}>
                    <XAxis dataKey="date" angle={-35} textAnchor="end" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="amount" fill="#38bdf8" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="log">
          <Card>
            <CardContent className="pt-4 space-y-2">
              {savings.length === 0 ? (
                <p className="text-sm text-center text-gray-500">No savings yet.</p>
              ) : (
                savings.map((entry) => (
                  <div key={entry.id} className="flex justify-between">
                    <span>{entry.date}</span>
                    <span>₦{entry.amount.toLocaleString()}</span>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
